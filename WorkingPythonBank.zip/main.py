import random
from Deposit_Withdraw import withbillcounter
from Deposit_Withdraw import depobillcounter
newAccountCreated = False
accountName = ""
accountNumber = ""
cardNumber = ""
cardCVV = ""
accountPin = ""
cardExpr = ""
bal = 0
stringbal = ""

accountInfo = ""
found = False
loggedIn = False
doesExist = False

class Card:
  def __init__(self, cardNumber, CVV, exprDate, pin):
    self.cardNum = cardNumber
    self.cardCVV = CVV
    self.exireDate = exprDate
    self.cardPin = pin
  def newAccount():
    file = open("AccountList.txt", 'a')
    file.write(accountName + ", " + accountNumber +  ", " + cardNumber + ", " + cardCVV + ", " + cardExpr + ", " + accountPin + "\n")
    file.close()

  def Card0(pin):
    global cardNumber
    global cardCVV
    global cardExpr
    global cardPin
    cardPin = pin
    first = random.randint(1000, 9000)
    second = random.randint(1000, 9000)
    third = random.randint(1000, 9000)
    fourth = random.randint(1000, 9000)
    cardNumber = "" + str(first) + "-" + str(second) + "-" + str(third) + "-" + str(fourth)
    randomcvv = random.randint(1, 900)
    cardCVV = "" + str(randomcvv)
    month = random.randint(5, 12)
    cardExpr = "" + str(month) + "/22"



#Checks to see if the user already exists while creating a new user
def userCheck(name):
  global doesExist
  file1 = open('AccountList.txt', 'r')
  Lines = file1.readlines()
  count = 0
  for line in Lines:
    if name in line:
      print("User already exists")
      doesExist = True

#Checks the AccountList file to see if the user is already in there for the login
def userAuth(name, pin):
  global accountInfo
  global loggedIn
  file1 = open('AccountList.txt', 'r')
  Lines = file1.readlines()
  count = 0
  found = False
  for line in Lines:
    if name in line:
      print("User Authorized!")
      found = True
      loggedIn = True;
      accountInfo = line
  if not found:
    print("User Not Authorized")
    loggedIn = False

#hops through the accountInfo string and sets the values to what they need to be
def stringHopping():
  global accountName
  global accountNumber
  global cardNumber
  global cardCVV
  global accountPin
  global cardExpr
  global stringbal
  global accountInfo
  tmp0 = 0
  tmp1 = 0
  j = 0
  counter = 0
  length = len(accountInfo)
  while j < length:
    if accountInfo[j] == ',':
      tmp1 = accountInfo.index(accountInfo[j])
      if counter == 0:
        accountName = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 1:
        accountNumber = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 2:
        cardNumber = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 3:
        cardCVV = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 4:
        accountPin = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 5:
        cardExpr = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      if counter == 6:
        stringbal = accountInfo[tmp0:tmp1]
        accountInfo = accountInfo[tmp1 + 2:length]
      counter += 1
      length = len(accountInfo)
    j = j + 1

def loginScreen():
  global stringbal
  global accountNumber
  global accountName
  i = 0
  decision = ""
  deposited = False
  while decision != "log out":
    decision = input("You can either deposit, withdraw, view account info, hint, or log out: ")
    if decision == "deposit" or decision == "Deposit":
      deposited = True
      #deposite function call
      depobillcounter(accountName)
      stringbal = "" + str(bal);
    elif decision == "withdraw" or decision == "Withdraw":
      #Withdraw function call
      withbillcounter(accountName)
      stringbal = "" + str(bal)
    elif decision == "withdraw" or decision == "Withdraw" and not deposited:
      print("You must deposit before you withdraw ")
    elif decision == "view account info" or decision == "View account info":
      stringHopping()
      print("Account holder: " + accountName)
      print("Account number: " + accountNumber)
      print("Balance: $" + str(bal))
      print("Card info: " + cardNumber + " " + cardCVV + " " + cardExpr)
    elif decision == "Hint" or decision == "hint":
      i = i + 1
      if i == 1:
        print("Your first hint: ")
      elif i == 2:
        print("Your second hint:")
      elif i == 3:
        print("Your final hint:")
 

#Main
firstDecision = ""
print("Welcome to Cameron's Bank, we are currently encountering some issues with our program! Please check over the code to find and fix the data structures that might've gone missing.")
while firstDecision != "exit" and not loggedIn and not doesExist:
  firstDecision = input("You can either Login or create an account: ")
  if firstDecision == "create an account":
    newAccountCreated = True
    firstAndLast = input("Please enter your first and last name: ")
    accountName = firstAndLast
    userCheck(firstAndLast)
    if(not doesExist):
      print("An account number will be generated for you.")
      acctNum = random.randint(1, 10000)
      accountNumber = " " + str(acctNum)
      print("You account number is: " + accountNumber)
      cardDes = input("Do you already have a card? (Yes/No): ")
      if cardDes == "no" or cardDes == "No":
        print("One will be generated for you and added to your account.")
        pin = input("Please enter a pin (XXXX): ")
        newCard0 = Card.Card0(pin)
        print("Your card number is: " + cardNumber)
        print("Your CVV is: " + cardCVV)
        print("Your card's expiration date is: " + cardExpr)
      elif cardDes == "yes":
        cardNum = input("Please enter your card number with dashes: ")
        cardCVV = input("Please enter your CVV (XXX): ")
        cardExpr = input("Please enter your cards expiration date (mm/yy): ")
        accountPin = input("Please enter a pin (XXXX): ")
        newCard = Card(cardNum, cardCVV, cardExpr, accountPin)
      Card.newAccount()
      print("Account Created!")
    elif(doesExist):
      print("You already have an account")
                
  elif firstDecision == "login":
    actName = input("Account Name: ")
    pin = input("Pin: ")
    userAuth(actName, pin)
    if loggedIn:
      print("Log in successful")
      loginScreen()
    else:
      print("User unauthorized")
  print("Please log in")
  actName = input("Account Name: ")
  pin = input("Pin: ")
  userAuth(actName, pin)
  if loggedIn:
    print("Log in successful")
    loginScreen()
  else:
    print("User unauthorized")