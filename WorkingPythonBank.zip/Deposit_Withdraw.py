#Need to fix withdraw and implement deque
from collections import deque
from pythonds.basic import Stack
from pythonds.basic import Queue
from pythonds.basic import Deque
import random
import time
#from pythonds.basic import List

#Declaring our stacks for different bill types
#Stack and Queue implementation
fiftiesStack = Stack()
hundredsStack = Stack()
twentiesStack = Stack()
tensStack = Stack()
fivesStack = Stack()
onesStack = Stack()


finalAmount = 0
depoAmount = 0
billcounter = 0

hundreds = 0
fifties = 0
twenties = 0
tens = 0
fives = 0
ones = 0

accountName = ""

def accountHolder(acctName, acctBal):
  global finalAmount
  finalAmount = acctBal
  global holder
  holder = []
  global holderName
  holderName = acctName
  global holderAcctNum
  holderAcctNum = random.randint(1,100)
  holderAcctNum *= 1324
  holder.append(acctName)
  holder.append(holderAcctNum)
  holder.append(acctBal)
  print("Account name: " + str(acctName))
  print("Account number: " + str(holderAcctNum))
  print("Account balance: $" + str(acctBal))

#Needs to be modified and made shorter
def depobillcounter(name):
  #Accessing the global variables to use them in the func
  global finalAmount
  global holder
  global hundreds
  global fifties
  global twenties
  global tens
  global fives
  global ones
  global billcounter
  accountName = name
  i = 0
  depoAmount = 0

  onesinput = 0
  #Adding ones
  onesinput = int(input("How many 1s would you like to deposit? "))
  while i < onesinput:
    onesStack.push(1)
    i += 1
    ones += 1
    finalAmount = int(finalAmount) + 1
  i = 0
  #Adding fives
  fivesinput = int(input("How many 5s would you like to deposit? "))
  while i < fivesinput:
    fivesStack.push(5)
    i = i + 1
    fives += 5
    finalAmount = int(finalAmount) + 5
  i = 0
  #adding tens
  tensinput = int(input("How many 10s would you like to deposit? "))
  while i < tensinput:
    tensStack.push(10)
    i += 1
    tens += 10
    finalAmount = int(finalAmount) + 10
  i = 0
  #Adding twenties
  twentiesinput = int(input("How many 20s would you like to deposit? "))
  while i < twentiesinput:
    twentiesStack.push(20)
    i += 1
    twenties += 20
    finalAmount = int(finalAmount) + 20
  i = 0
  #Adding fifties
  fiftiesinput = int(input("How many 50s would you like to deposit? "))
  while i < fiftiesinput:
    fiftiesStack.push(50)
    i = i + 1
    fifties += 50
    finalAmount = int(finalAmount) + 50
  i = 0
  #Adding hundreds
  hundredsinput = int(input("How many 100s would you like to deposit? "))
  while i < hundredsinput:
    hundredsStack.push(100)
    i += 1
    hundreds += 100
    finalAmount = int(finalAmount) + 100
  i = 0
  #Printing out the value that the user has in each bill value, then the final
  print("You now have $" + str(hundreds) + " in hundreds, $" + str(fifties) + " in fifties, $"+ str(twenties) + " in twenties, $" + str(tens) + " in tens, $" + str(fives) + " in fives, $" + str(ones) + " in ones")
  print("For a final balance of $" + str(finalAmount))
  #Modifying the amount in the users account

def withbillcounter(name):
  global finalAmount
  global holder
  #Monetary value that is incrementing for each bill being deposited
  hundreds = 0
  fifties = 0
  twenties = 0
  tens = 0
  fives = 0
  ones = 0
  i = 0
  withAmount = 0

  onesinput = 0
  fivesinput = 0
  tensinput = 0
  twentiesinput = 0
  fiftiesinput = 0
  hundredsinput = 0
  #Checking to see if the stacks are empty. If they are empty, give the user an error
  if onesStack.isEmpty() and fivesStack.isEmpty() and tensStack.isEmpty() and twentiesStack.isEmpty() and fiftiesStack.isEmpty() and hundredsStack.isEmpty():
    print("There are no bills to take out. Returning you to the main menu")
  #If the stacks are nto empty, go through with the withdraw func
  elif onesStack.size() >= 1 or fivesStack.size() >= 1 or tensStack.size() >= 1 or twentiesStack.size() >= 1 or fiftiesStack.size() >= 1 or hundredsStack.size() >= 1:
    #Asking the user for bills, adding them to the correct stack, and adding to the final monetary value for that bill
    #ones
    while onesinput == 0 or onesinput > onesStack.size():
      onesinput = int(input("How many 1s would you like to withdraw? "))
      if onesinput > onesStack.size():
        print("You don't have that many ones, try another amount.")
    while i < onesinput:
      onesStack.pop()
      i += 1
      ones -= 1
      withAmount = int(withAmount) + 1
    i = 0
    #fives
    while fivesinput == 0 or fivesinput > fivesStack.size():
      fivesinput = int(input("How many 5s would you like to withdraw? "))
      if fivesinput > fivesStack.size():
        print("You don't have that many fives, try another amount.")
    while i < fivesinput:
      fivesStack.pop()
      i += 1
      fives -= 5
      withAmount += 5
    i = 0
    #tens   
    while tensinput == 0 or tensinput > tensStack.size():
      tensinput = int(input("How many 10s would you like to withdraw? "))
      if tensinput > tensStack.size():
        print("You don't have that many tens, try another amount.")
    while i < tensinput:
      tensStack.pop()
      i -= -1
      tens -= 10
      withAmount += 10
    i = 0
    #twenties
    while twentiesinput == 0 or twentiesinput > twentiesStack.size():
      twentiesinput = int(input("How many 20s would you like to withdraw? "))
      if twentiesinput > twentiesStack.size():
        print("You don't have that many twenties, try another amount.")
    while i < twentiesinput:
      twentiesStack.pop()
      i += 1
      twenties -= 20
      withAmount += 20
    i = 0
    #fifties
    while fiftiesinput == 0 or fiftiesinput > fiftiesStack.size():
      fiftiesinput = int(input("How many 50s would you like to withdraw? "))
      if fiftiesinput > twentiesStack.size():
        print("You don't have that many fifties, try another amount.")
    while i < fiftiesinput:
      fiftiesStack.pop()
      i += 1
      fifties -= 50
      withAmount += 50
    i = 0
    #hundreds
    while hundredsinput == 0 or hundredsinput > hundredsStack.size():
      hundredsinput = int(input("How many 100s would you like to withdraw? "))
      if hundredsinput > hundredsStack.size():
        print("You don't have that many hundreds, try another amount.")
    while i < hundredsinput:
      hundredsStack.pop()
      i += 1
      hundreds -= 100
      withAmount += 100
    i = 0
    
    finalAmount = int(finalAmount) - int(withAmount)
    print("You now have $" + str(hundreds) + " in hundreds, $" + str(fifties) + " in fifties, $"+ str(twenties) + " in twenties, $" + str(tens) + " in tens, $" + str(fives) + " in fives, $" + str(ones) + " in ones")
    print("For a final balance of $" + str(finalAmount - withAmount))

def subtracting(valinput, billstack, billcounter, bill):
  #Accesses the depositAmount and the finalamount
  global depoAmount
  global finalAmount
  i = 0
  #Adds the bills to the stack for each bill
  while i < valinput:
    billstack.push(bill)
    #Increments the counter
    i -= 1
    #Adds the bill to the counter for that bill
    billcounter -= bill
    #Adds the bill to the finalAmount in the account
    finalAmount = billcounter
  #Returns how much is being added in this function
  return billcounter


def getAcctNum():
  return "Account number: " + str(holderAcctNum)


