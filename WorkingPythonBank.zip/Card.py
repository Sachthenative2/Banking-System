import random
from main import getAccountNumber
from main import AccountName
holderName = AccountName
cardNum = ""
cardCVV = ""
expireDate = ""
cardPin = ""
class Card:
  def __init__(self, cardNumber, CVV, exprDate, pin):
    self.cardNum = cardNumber
    self.cardCVV = CVV
    self.exireDate = exprDate
    self.cardPin = pin
  def newAccount():
    file = open("AccountList.txt")
    file.write(holderName + ", " + getAccountNumber() + ", " + cardNum + ", " + cardCVV + ", " + expireDate + ", " + cardPin + "\n")
    file.close()
  
  #Getters
  def getHolderName():
    return holderName
  def getCardNum():
    return cardNum
  def getCardCVV():
    return cardCVV
  def getExpireDate():
    return expireDate
  def getCardPin():
    return cardPin

"""
  def Card0(pin):
    global cardPin
    global cardNum
    global cardCVV
    global expireDate
    cardPin = pin
    first = random.randint(1000, 9000)
    second = random.randint(1000, 9000)
    third = random.randint(1000, 9000)
    fourth = random.randint(1000, 9000)
    cardNum = "" + first + "-" + second + "-" + third + "-" + fourth
    randomcvv = random.randint(1, 900)
    cardCVV = "" + randomcvv
    month = random.randint(5, 12)
    expireDate = "" + random

"""